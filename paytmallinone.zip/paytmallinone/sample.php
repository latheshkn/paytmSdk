<?php

/* import checksum generation utility */
require_once("./PaytmChecksum.php");

/* initialize an array */
$paytmParams = array();

/* add parameters in Array */
$paytmParams["MID"] = "uHykBm20360288053432";
$paytmParams["ORDERID"] = "order_123";

/**
* Generate checksum by parameters we have
* Find your Merchant Key in your Paytm Dashboard at https://dashboard.paytm.com/next/apikeys 
*/
$paytmChecksum = PaytmChecksum::generateSignature($paytmParams, 'pXD_RjTIcsfFnDNM');
echo sprintf("generateSignature Returns: %s\n", $paytmChecksum);