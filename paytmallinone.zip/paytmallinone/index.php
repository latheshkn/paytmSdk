<?php
header("Location:http://iinvoice.in"); 


?>